
string = input("Enter your string: ")
print("The even indexed string is:", string[0::2], end="");
