#Exercise-02

def areaAndPerimeter (r):
    area = 3.14 * r * r
    print("Area is:", area)
    perimeter = 2 * 3.14 * r
    print("Perimeter is:", perimeter)

r = float(input("Enter the radius: "))
areaAndPerimeter(r)
