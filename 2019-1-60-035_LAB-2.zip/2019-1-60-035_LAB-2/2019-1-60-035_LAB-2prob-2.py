num = [i for i in range(1, 1001) if '6' in str(i)]
print("The numbers from 1–1000 that have a 6 in them are given below: ")
print(num)