string = "Practice Problems to Drill List Comprehension in Your Head."
print("The number of spaces in string is:", string.count(" "))