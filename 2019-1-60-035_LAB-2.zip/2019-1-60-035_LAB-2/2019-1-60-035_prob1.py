num = [i for i in range(1, 1001) if i % 8 == 0]
print('The numbers from 1–1000 that are divisible by 8 are given below: ')
print(num)
